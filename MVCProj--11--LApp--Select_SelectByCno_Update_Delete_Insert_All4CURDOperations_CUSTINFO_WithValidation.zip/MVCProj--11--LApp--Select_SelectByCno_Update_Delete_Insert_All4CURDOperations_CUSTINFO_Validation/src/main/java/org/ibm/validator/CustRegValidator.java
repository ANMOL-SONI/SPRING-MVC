package org.ibm.validator;

import org.ibm.command.CustCommand;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class CustRegValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
			
//		return clazz==CustCommand.class;
			return clazz.isAssignableFrom(CustCommand.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
			System.out.println("CustRegValidator----------->.validate()");
			
			CustCommand cmd=null;
			cmd=(CustCommand) target;
			
			// get vflag value to enable disable server side form validation
			String vstatus=null;
			vstatus=cmd.getVflag();
			
			if(vstatus.equalsIgnoreCase("off")) {
				System.out.println(" Server Side Form validation Logics .......");
				
				//PolicyRequired and rules to follow 
				
				//its Integer type	
				if(String.valueOf(cmd.getCno())==null)
					errors.rejectValue("cno", "cust.no.required");
//					else if(cmd.getCno().toString().length()!=2)
							else if(String.valueOf(cmd.getCno()).length()!=2)
								errors.rejectValue("cno","cust.no.length");
									else if(cmd.getCno().intValue()<0)
										errors.rejectValue("cno","cust.no.type");
				
				
							if(cmd.getCname()==null || cmd.getCname().equals("") || cmd.getCname().length()==0)
									errors.rejectValue("cname", "cust.name.required");
				
				
				
							if(cmd.getCadd()==null || cmd.getCadd().equals("") || cmd.getCadd().length()==0)
								errors.rejectValue("cadd", "cust.addrs.required");
									else if(cmd.getCadd().length()<10)
										errors.rejectValue("cadd", "cust.addrs.minlen");
											else if(cmd.getCadd().length()>15)
												errors.rejectValue("cadd", "cust.addrs.maxlen");
//												else if(cmd.getCadd().length()<5 || cmd.getCadd().length()>15)
//													errors.rejectValue("addrs","custCmd.custAddrs.range");

						//its Long type	
							if(String.valueOf(cmd.getMobileNo())==null)
								errors.rejectValue("mobileNo", "cust.mobile.required");
//								else if(cmd.getMobileNo().toString().length()!=10)
										else if(String.valueOf(cmd.getMobileNo()).length()!=10)
											errors.rejectValue("mobileNo","cust.mobile.length");
												else if(cmd.getMobileNo().intValue()<0)
													errors.rejectValue("mobileNo","cust.mobile.type");
							
						//Its Float type
							if(String.valueOf(cmd.getBillAmt())==null)
								errors.rejectValue("billAmt","cust.billAmt.required");
									else if(cmd.getBillAmt()<=0 || cmd.getBillAmt()>100000)
										errors.rejectValue("billAmt","cust.billAmt.range");
			}//if
		
	}//method

}//class
