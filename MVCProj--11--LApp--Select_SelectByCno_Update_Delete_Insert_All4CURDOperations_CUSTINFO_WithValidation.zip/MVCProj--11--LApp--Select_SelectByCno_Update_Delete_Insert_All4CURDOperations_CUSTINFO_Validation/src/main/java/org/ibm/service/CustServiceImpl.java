package org.ibm.service;

import java.util.ArrayList;
import java.util.List;

import org.ibm.bo.CustBO;
import org.ibm.dao.CustDAO;
import org.ibm.dto.CustDTO;
import org.springframework.beans.BeanUtils;

public class CustServiceImpl implements CustService {
		private CustDAO dao;
	
	
	public CustServiceImpl(CustDAO dao) {
			this.dao = dao;
		}


	@Override
	public List<CustDTO> nowFetchAllCusts_Fr0mDAOBO_putinDTO_passtoController_Method() {
		

		//Create ListCollectionBox, Use Space, add Masala and Prepare to return
		List<CustDTO> listDTO=new ArrayList<>();
		
		
		//use DAO //Now Use DAO Method fetch all related CarS to that listBO for a moment  By Passing  bo param input values... 
		List<CustBO> listBO=null;
											 listBO=dao.getAllCusts_Fr0mDBTableRSList_putinBO_passtoService_Method();
											
		//3 values putting and getting 15 records Which is stored in listBO
		//Now convert listBO to listDTO to give controller bhai ...
											 
		listBO.forEach(boTo->{
			CustDTO dto=new CustDTO();
			BeanUtils.copyProperties(boTo, dto);
			dto.setSrNo(listDTO.size()+1);
			listDTO.add(dto);
		});
		
		//or sample
		
//		EmployeeDTO dto=null;
//		for(EmployeeBO bo:listBO) {
//			 dto=new EmployeeDTO();
//			 BeanUtils.copyProperties(bo, dto);
//			 dto.setSrno(listDTO.size()+1);
//			 listDTO.add(dto);

return listDTO;

	}


	@Override
	public CustDTO fetchCustByCno(int cno) {

		//Create ListCollectionBox, Use Space, add Masala and Prepare to return
		CustDTO dto=null;
							dto=new CustDTO();

		
		//use DAO //Now Use DAO Method fetch all related CarS to that listBO for a moment  By Passing  bo param input values... 
		CustBO bo=null;
						bo=dao.getCustByCno(cno);
						
		//Now copy BO  to DTO

		BeanUtils.copyProperties(bo, dto);								 

return dto;
	}


	@Override
	public String modifyCustByNo(CustDTO dto) {
		CustBO bo=null;
		int count=0;
		//convert DTO to BO
		bo=new CustBO();
	   BeanUtils.copyProperties(dto,bo);
	   //use DAO
	   count=dao.updateCustByNo(bo);
		if(count==0)
			return "Record not found for updation";
		else
			return "Record  found and updated";
	}


	@Override
	public String removeCustByCno(int cno) {

		int count=0;
		//use DAO
		count=dao.deleteCustByCno(cno);
		if(count==0)
			return "Customer not found for Deletion";
		else
			return "Customer  found and Deleted";
	}
	

	@Override
	public String registerAllCars_Fr0mDAO_putinBO_passtoDAO_Method(CustDTO dto) {
							
		int count=0;
		
		CustBO bo=new CustBO();
		//convert DTO to BO
		BeanUtils.copyProperties(dto,bo);
      //use DAO
		count=dao.insertAllCustInfo_Fr0mBOgivenByService_putinRSListObj_passtoDB_Method(bo);
		//process the Result
		if(count==0)
			return  "SORRY !!!   The Registration has been Failed due to some reasone ,Please Try Again !!! ";
		else
			return  "Congratulations !!! The Registration has been Succeded with no compromise ... ENJOY !!!";
		
	}//method

}//class
