package org.ibm.service;

import java.util.List;

import org.ibm.dto.CustDTO;

public interface CustService {
	
	public List<CustDTO> nowFetchAllCusts_Fr0mDAOBO_putinDTO_passtoController_Method();

	public CustDTO fetchCustByCno(int cno);
	
	public  String modifyCustByNo(CustDTO dto);
	
	public  String  removeCustByCno(int cno);
	
	public String registerAllCars_Fr0mDAO_putinBO_passtoDAO_Method(CustDTO dto);
	
}
