package org.ibm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.ibm.command.CustCommand;
import org.ibm.dto.CustDTO;
import org.ibm.service.CustService;
import org.springframework.beans.BeanUtils;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

@SuppressWarnings("deprecation")
public class CustController extends SimpleFormController {
		private CustService service;
	
	
	
	public CustController(CustService service) {
		System.out.println("CarSearchController------------1--------------paran cons");
			this.service = service;
		}



	@Override
	protected ModelAndView onSubmit(HttpServletRequest req, HttpServletResponse res, Object command,
			BindException errors) throws Exception {
		
											
						//i command to search by that inputs
						CustCommand cmd=null;
						cmd=(CustCommand) command;
						
						//Application logic errors
						if(cmd.getCadd().equalsIgnoreCase("BangaloreCity")) {
							errors.rejectValue("cadd","cust.addrs.restriction");
							return  showForm(req, res,errors);
						}

						//First those 3 inputs hold by dto
						CustDTO dto=null;
											dto=new CustDTO();
											
						// now copy same given input values ...
						BeanUtils.copyProperties(cmd, dto);
						
						//Use Service
						String resultMsg=null;
										resultMsg=service.registerAllCars_Fr0mDAO_putinBO_passtoDAO_Method(dto);
										
						List<CustDTO> listDTO=null;										
										listDTO=service.nowFetchAllCusts_Fr0mDAOBO_putinDTO_passtoController_Method();
						//return MAV object to DS with view name report.jsp , $(searchResults) fetched from listRDTO .. 
//						return new ModelAndView("report","custs",resultMsg);
						ModelAndView mav=null;
														mav=new ModelAndView();
														mav.addObject("listDTO",listDTO);
														mav.addObject("resMsg",resultMsg);
														mav.setViewName("list_customers");
														return mav;
																
	}//method
	
	
	@Override
	public ModelAndView handleInvalidSubmit(HttpServletRequest req, HttpServletResponse res)
		throws Exception {
			System.out.println("CustController----------------->.handleInvalidSubmit()");
			return new ModelAndView("UIdblPostingErrorMsg");
	}
	
	@Override
	public Object formBackingObject(HttpServletRequest req) throws Exception {
		System.out.println("CustController------------------>.formBackingObject()");
		
		CustCommand cmd=null;
										cmd= new CustCommand();
					
										
		cmd.setCno((int) (Math.random()*100));								
		cmd.setCadd("BangaloreCity");
		cmd.setBillAmt((float) (Math.random()*1000000.0f));
		
		
	return cmd;
	}
	

}//class
