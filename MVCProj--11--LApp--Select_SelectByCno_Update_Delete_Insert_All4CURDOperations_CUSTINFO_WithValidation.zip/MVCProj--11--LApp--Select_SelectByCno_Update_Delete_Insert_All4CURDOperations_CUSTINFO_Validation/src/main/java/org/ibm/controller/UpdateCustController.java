package org.ibm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.ibm.command.CustCommand;
import org.ibm.dto.CustDTO;
import org.ibm.service.CustService;
import org.springframework.beans.BeanUtils;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

@SuppressWarnings("deprecation")
public class UpdateCustController extends SimpleFormController {
		private CustService service;
	
	
	
	public UpdateCustController(CustService service) {
		System.out.println("CarSearchController------------1--------------paran cons");
			this.service = service;
		}

	@Override
	public Object formBackingObject(HttpServletRequest req) throws Exception {
		System.out.println("UpdateCustomerController.formBackingObject()");
	    int cno=0;
	    CustDTO dto=null;
	    CustCommand cmd=null;
		//read customer number from hyperlink
	    cno=Integer.parseInt(req.getParameter("cno"));
	    //use service
	    dto=service.fetchCustByCno(cno);
	    //create and Command class obj having dynamic initial values
	    cmd=new CustCommand();
	    BeanUtils.copyProperties(dto, cmd);
	    return cmd;
		
	}
	
	@Override
	public ModelAndView onSubmit(HttpServletRequest req, HttpServletResponse res, Object command,
			BindException errors) throws Exception {
		CustCommand cmd=null;
		CustDTO dto=null;
		String resultMsg=null;
		List<CustDTO> listDTO=null;
		ModelAndView mav=null;
		//type casting
		cmd=(CustCommand)command;
		//Convert Command class obj to DTO class obj
		dto=new CustDTO();
		BeanUtils.copyProperties(cmd, dto);
		//use service
		resultMsg=service.modifyCustByNo(dto);
		listDTO=service.nowFetchAllCusts_Fr0mDAOBO_putinDTO_passtoController_Method();
		
		//create and return MAV obj
		mav=new ModelAndView();
		mav.addObject("listDTO",listDTO);
		mav.addObject("resMsg",resultMsg);
		mav.setViewName("list_customers");
		return mav;
	}//method
	
	@Override
	public ModelAndView handleInvalidSubmit(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		return new  ModelAndView("UIdblPostingErrorMsg");
	}
}//class
