package org.ibm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.ibm.dto.CustDTO;
import org.ibm.service.CustService;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class DeleteCustController extends AbstractController {
		private CustService service;
	
	
	
	public DeleteCustController(CustService service) {
		System.out.println("CarSearchController------------1--------------paran cons");
			this.service = service;
		}

	@Override
	public ModelAndView handleRequestInternal(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		int cno=0;
		String resMsg=null;
		ModelAndView mav=null;
		List<CustDTO> listDTO=null;
		//read additonal req param values
		cno=Integer.parseInt(req.getParameter("cno"));
		//use Service  class
		resMsg=service.removeCustByCno(cno);
		listDTO=service.nowFetchAllCusts_Fr0mDAOBO_putinDTO_passtoController_Method();
		//create and return MAV object 
		mav=new ModelAndView();
		mav.addObject("listDTO",listDTO);
		mav.addObject("resMsg",resMsg);
		mav.setViewName("list_customers");
		return mav;
	}//method

}//class
