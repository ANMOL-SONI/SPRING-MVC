package org.ibm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.ibm.dto.CustDTO;
import org.ibm.service.CustService;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class ListCustController extends AbstractController {
		private CustService service;
	
	
	
	public ListCustController(CustService service) {
		System.out.println("CarSearchController------------1--------------paran cons");
			this.service = service;
		}


	@Override
	public ModelAndView handleRequestInternal(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		List<CustDTO> listDTO=null;
		//use Service
		listDTO=service.nowFetchAllCusts_Fr0mDAOBO_putinDTO_passtoController_Method();
		//create and return MAV obj
		return new ModelAndView("list_customers","listDTO",listDTO);
	}//method

}//class
