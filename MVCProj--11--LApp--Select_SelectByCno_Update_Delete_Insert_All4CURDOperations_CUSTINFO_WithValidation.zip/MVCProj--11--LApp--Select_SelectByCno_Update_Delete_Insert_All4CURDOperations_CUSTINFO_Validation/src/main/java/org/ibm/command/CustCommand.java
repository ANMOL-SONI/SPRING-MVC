package org.ibm.command;

import lombok.Data;

@Data
public class CustCommand {

	private Integer cno;			
	private String cname;
	private String cadd;
	private Long mobileNo;
	private Float billAmt;
	private String vflag="off";
	
	
	
	public CustCommand() {
		System.out.println("CustCommand --------------0-------param cons");
	}
	
}
