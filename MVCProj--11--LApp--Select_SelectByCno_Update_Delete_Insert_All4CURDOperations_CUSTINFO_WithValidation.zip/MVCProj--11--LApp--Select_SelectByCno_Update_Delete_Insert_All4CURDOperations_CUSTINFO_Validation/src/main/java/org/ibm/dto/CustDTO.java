package org.ibm.dto;

import java.io.Serializable;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class CustDTO implements Serializable {

	private int srNo;
	private int cno;
	private String cname;
	private String cadd;
	private long mobileNo;
	private float billAmt;
				
				
						
}
