package org.ibm.dao;

import java.util.List;

import org.ibm.bo.CustBO;

public interface CustDAO {
	
	
					
					public List<CustBO> getAllCusts_Fr0mDBTableRSList_putinBO_passtoService_Method();
					
					public CustBO getCustByCno(int cno);
					
					public int updateCustByNo(CustBO bo);
					
					public int deleteCustByCno(int cno);
					
					public int insertAllCustInfo_Fr0mBOgivenByService_putinRSListObj_passtoDB_Method(CustBO bo);

					
					
}
