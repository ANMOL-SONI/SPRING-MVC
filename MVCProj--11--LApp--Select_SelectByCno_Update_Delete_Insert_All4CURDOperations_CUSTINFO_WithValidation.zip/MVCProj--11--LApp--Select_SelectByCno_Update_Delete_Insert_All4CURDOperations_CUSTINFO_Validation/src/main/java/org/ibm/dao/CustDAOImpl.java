package org.ibm.dao;

import java.util.List;

import org.ibm.bo.CustBO;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapperResultSetExtractor;

public class CustDAOImpl implements CustDAO {
	
	private static final String  GET_ALL_CUSTOMERS="SELECT CNO,CNAME,CADD,MOBILENO,BILLAMT FROM CUSTINFO";
	private static final String  GET_CUSTOMER_BY_CNO="SELECT  CNO,CNAME,CADD,MOBILENO,BILLAMT FROM CUSTINFO WHERE CNO=?";
	private static final  String  UPDATE_CUSTOMER_BY_CNO="UPDATE CUSTINFO SET CNAME=?,CADD=?,MOBILENO=?,BILLAMT=? WHERE CNO=?";
	private static final  String  DELETE_CUSTOMER_BY_CNO="DELETE FROM CUSTINFO  WHERE CNO=?";
	private static final String INSERT_CUST="INSERT INTO CUSTINFO VALUES(CNO_SEQ.NEXTVAL,?,?,?,?)";
	
		private JdbcTemplate jt;
	
	
	public CustDAOImpl(JdbcTemplate jt) {
			this.jt = jt;
		}


	@Override
	public List<CustBO> getAllCusts_Fr0mDBTableRSList_putinBO_passtoService_Method() {
		
		// Now Copy One by One Row record From-- DBTable records by creating and using-- RowMapperResultSetExtractor  ...
		BeanPropertyRowMapper<CustBO> rowMapper=null;
																						rowMapper=new BeanPropertyRowMapper<>(CustBO.class);
		
		// Create ListCollectionBox, Use Space, add Masala and Prepare to return CustultBO as List ...
		List<CustBO> listBO=null;
		//Now Copy One by One object From -- RowMapperResultSetExtractor records by using -- BeanPropertyRowMapper to -- Collection ListRBO obj ...
									 listBO=(List<CustBO>)jt.query(GET_ALL_CUSTOMERS,new RowMapperResultSetExtractor<>(rowMapper));
									 /*
									  listBO=jt.query(GET_ALL_CUSTOMERS,
						                         rs->{
						                        	 List<CustomerBO> listBO1=null;
						                        	 CustomerBO bo=null;
						                        	 listBO1=new ArrayList();
						                        	 while(rs.next()) {
						                        		 bo=new CustomerBO();
						                        		 bo.setCno(rs.getInt(1));
						                        		 bo.setCname(rs.getString(2));
						                        		 bo.setCadd(rs.getString(3));
						                        		 bo.setMobileNo(rs.getLong(4));
						                        		 bo.setBillAmt(rs.getFloat(5));
						                        		 listBO1.add(bo);
						                        	 }//while
						                        	 return listBO1;
						                         });
									  */
return listBO;
}//method


	@Override
	public CustBO getCustByCno(int cno) {
		CustBO bo=null;
		bo=jt.queryForObject(GET_CUSTOMER_BY_CNO,
				                                (rs,index)->{
				                                	CustBO bo1=new CustBO();
				                                	bo1.setCno(rs.getInt(1));
				                                	bo1.setCname(rs.getString(2));
				                                	bo1.setCadd(rs.getString(3));
				                                	bo1.setMobileNo(rs.getLong(4));
				                                	bo1.setBillAmt(rs.getFloat(5));
				                                	return bo1;
				                                },
				                                cno);
				                               
		
		return bo;		


	}


	@Override
	public int updateCustByNo(CustBO bo) {

		int count=0;
		count=jt.update(UPDATE_CUSTOMER_BY_CNO,bo.getCname(),bo.getCadd(),bo.getMobileNo(),bo.getBillAmt(),bo.getCno());
		return count;
		
	}


	@Override
	public int deleteCustByCno(int cno) {

		int  count=0;
		count=jt.update(DELETE_CUSTOMER_BY_CNO,cno);
		return count;
		
	}
	
	@Override
	public int insertAllCustInfo_Fr0mBOgivenByService_putinRSListObj_passtoDB_Method(CustBO bo) {
		
		int count=0;
		
		count=jt.update(INSERT_CUST,bo.getCname(),bo.getCadd(),bo.getMobileNo(),bo.getBillAmt());
		
		return count;
						
		
	}//method
		

}//class
	