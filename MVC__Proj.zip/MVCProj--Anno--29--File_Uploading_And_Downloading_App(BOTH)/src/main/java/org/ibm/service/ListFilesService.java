package org.ibm.service;

import java.util.List;

public interface ListFilesService {
	
	public  List<String>   getAllFiles(String  storePath);

}
