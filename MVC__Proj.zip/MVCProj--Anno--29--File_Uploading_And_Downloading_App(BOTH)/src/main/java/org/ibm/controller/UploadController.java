package org.ibm.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.ibm.command.UploadCommand;
import org.ibm.service.ListFilesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class UploadController {
	@Autowired
	private  ListFilesService service;


	@RequestMapping(value="/upload.htm",method = RequestMethod.GET)
	public   String  showForm(HttpServletRequest req,
														Map<String,Object> map,
														@ModelAttribute("uplCmd") UploadCommand cmd) {
		List<String> filesList=null;
		String  fileStore=null;
		//get Context Param value
		fileStore=req.getServletContext().getInitParameter("uploadFolder");
		//use service
		filesList=service.getAllFiles(fileStore);
		//put result in map
		map.put("filesList", filesList);
		return  "upload_form";
	}


	@RequestMapping(value="/upload.htm",method = RequestMethod.POST)
	public  String    upload(HttpServletRequest req,
												Map<String,Object> map,
												@ModelAttribute("uplCmd") UploadCommand cmd)
														throws Exception {
		
		ServletContext sc=null;
		String uplFolder=null;
		File file=null;
		String fname1=null,fname2=null;
		InputStream  is1=null,is2=null; 
		OutputStream  os1=null,os2=null;
		
		//get SErvletContext obj
		sc=req.getServletContext();
		
		//read context param value
		uplFolder=sc.getInitParameter("uploadFolder");
		
		//create or locate folder
		file=new File(uplFolder);
		if(!file.exists())
			  file.mkdir();
		
		//get the name of uploaded files..
		fname1=cmd.getFile1().getOriginalFilename();
		fname2=cmd.getFile2().getOriginalFilename();
		
		//create InputStream pointing  to uploaded files.. 
		is1=cmd.getFile1().getInputStream();
		is2=cmd.getFile2().getInputStream();
		
		//create OutputStreams pointing to dest files (empty)..
		os1=new FileOutputStream(file.getAbsolutePath()+"/"+fname1);
		os2=new FileOutputStream(file.getAbsolutePath()+"/"+fname2);
		
		//perform file copy activitity
		IOUtils.copy(is1, os1);
		IOUtils.copy(is2, os2);
		
		//add the uploaded file names as model Attributes
		map.put("fname1",fname1);
		map.put("fname2",fname2);
		
		//close streams
		is1.close();
		is2.close();
		os1.close();
		os2.close();
		
		return "upload_form";
	}
	

	@RequestMapping("/download.htm")
	public  void  download(@RequestParam("fileName") String fname,
			                                      HttpServletRequest req,
			                                      HttpServletResponse res)throws Exception{
		ServletContext sc=null;
		File file=null;
		InputStream is=null;
		OutputStream os=null;
		//get ServletContext object
		sc=req.getServletContext();
		//Locate the file to be downloaded
		file=new File(sc.getInitParameter("uploadFolder")+"/"+fname);
		//get lengh of the file and make it response content  length
		res.setContentLengthLong(file.length());
		//get MIME of the file  and make it response MIME type
		res.setContentType(sc.getMimeType(sc.getInitParameter("uploadFolder")+"/"+fname));
		// create Input Stream pointing to the file
		is=new FileInputStream(file);
		//create OuputStream pointing to response obj
		os=res.getOutputStream();
		//give instruction browser to make the recieved content of as downloadable file
		res.addHeader("Content-Disposition","attachment;fileName="+fname);
		//write the content of file to be downloaded to response object
		IOUtils.copy(is,os);
		//close streams
		is.close();
		os.close();
		
			//return ;
		}
}
