
package org.ibm.config;
import java.util.Locale;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "org.ibm.controller")
public class WebMVCAppConfig extends WebMvcConfigurerAdapter {
	
	public WebMVCAppConfig() {
		System.out.println("WebMVCAppConfig.0-param constructor");
	}
	
	
//	<!-- handler mapping -->
	
	@Bean(name="mapping")
	public   RequestMappingHandlerMapping  createRMHM(LocaleChangeInterceptor lci) {
		System.out.println("WebMVCAppConfig.createRMHM()");
		RequestMappingHandlerMapping mapping=null;
		mapping=new RequestMappingHandlerMapping();
		mapping.setInterceptors(lci);
		return mapping;
	}
	
//	 <!-- interceptor -->
	
@Override
	public void addInterceptors(InterceptorRegistry registry) {
			registry.addInterceptor(myInterceptor());
}
	
	@Bean(name="lci")
	public   LocaleChangeInterceptor  myInterceptor () {
		System.out.println("WebMVCAppConfig.myInterceptor ()");
		LocaleChangeInterceptor lci=null;
		lci=new LocaleChangeInterceptor();
		lci.setParamName("lang");
		return lci;
	}	
	
//	 <!-- Cfg base file  for I18n-->
	
	@Bean(name="messageSource")
	public   ResourceBundleMessageSource  mymessageSource() {
		System.out.println("WebMVCAppConfig.mymessageSource()");
		ResourceBundleMessageSource messageSource=null;
		messageSource=new ResourceBundleMessageSource();
		messageSource.setBasename("org/ibm/commons/App");
		messageSource.setDefaultEncoding("UTF-8");
		return messageSource;
	}
	
//	  <!-- Cfg Locale Resovler -->
	
	@Bean(name="localeResolver")
	public   SessionLocaleResolver  mylocaleResolver() {
		System.out.println("WebMVCAppConfig.mylocaleResolver()");
		SessionLocaleResolver localeResolver=null;
		localeResolver=new SessionLocaleResolver();
		localeResolver.setDefaultLocale(new Locale("hi","IN"));
//		localeResolver.setDefaultLocale(Locale.SIMPLIFIED_CHINESE);
		return localeResolver;
	}

//	<!-- View Resolver -->
	
	@Bean
	public   ViewResolver createIRVR() {
		System.out.println("WebMVCAppConfig.createIRVR()");
		InternalResourceViewResolver  resolver=null;
		resolver=new InternalResourceViewResolver();
		resolver.setPrefix("/WEB-INF/pages/");
		resolver.setSuffix(".jsp");
		return resolver;
		
	}
	
	

}
