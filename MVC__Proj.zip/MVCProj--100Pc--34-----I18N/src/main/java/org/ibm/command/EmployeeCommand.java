package org.ibm.command;

import lombok.Data;

@Data
public class EmployeeCommand {
	private int eid;
	private String ename;
	private  String addrs;
	private float salary;

}
